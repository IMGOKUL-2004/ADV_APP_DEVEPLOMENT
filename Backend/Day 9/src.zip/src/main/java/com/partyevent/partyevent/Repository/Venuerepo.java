package com.partyevent.partyevent.Repository;

import com.partyevent.partyevent.Entity.Venue;

import java.util.List;

// import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
// import java.util.List;


@Repository
public interface Venuerepo extends JpaRepository<Venue, Long> {

    @Query(value="select * from venue where eveid=:s",nativeQuery=true)
	public List<Venue> getchefid(@Param("s") long eveid);
}