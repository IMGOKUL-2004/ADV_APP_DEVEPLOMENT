
package com.partyevent.partyevent.Repository;

import com.partyevent.partyevent.Entity.Book;
import java.util.List;

// import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
// import java.util.List;


@Repository
public interface Bookrepo extends JpaRepository<Book, Long> {
    Book findByEventType(String eventType);
    Book findById(long userid);    
    void deleteByBookingID(Long bookingID);

    @Query(value="select * from Books where userid=:s",nativeQuery=true)
	public List<Book> getchefid(@Param("s") long userid);
    // void deleteByEventtype(String eventtype);
}