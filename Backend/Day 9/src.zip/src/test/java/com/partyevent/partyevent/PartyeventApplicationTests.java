package com.partyevent.partyevent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartyeventApplicationTests {

	@Test
	void contextLoads() {
	}

}
