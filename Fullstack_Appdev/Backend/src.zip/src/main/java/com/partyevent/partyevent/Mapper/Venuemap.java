package com.partyevent.partyevent.Mapper;


import com.partyevent.partyevent.dto.Venuedto;
import com.partyevent.partyevent.Entity.Venue;

public class Venuemap{

    public static Venuedto maptovenuedto(Venue serviceentity) {
        // Implement the mapping logic
        return new Venuedto(
                serviceentity.getVenueid(),
                serviceentity.getVenuename(),
                serviceentity.getVenuelocation(),
                serviceentity.getVenueimg(),
                serviceentity.getEveid()
        );
    }

    public static Venue maptovenueentity(Venuedto servicedto) {
        // Implement the mapping logic
        return new Venue(
                servicedto.getVenueid(),
                servicedto.getVenuename(),
                servicedto.getVenuelocation(),
                servicedto.getVenueimg(),
                servicedto.getEveid()
        );
    }
}