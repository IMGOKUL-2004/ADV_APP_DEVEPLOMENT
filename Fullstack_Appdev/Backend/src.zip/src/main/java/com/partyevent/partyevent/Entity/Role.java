package com.partyevent.partyevent.Entity;

public enum Role {
    USER,
    ADMIN;
}
