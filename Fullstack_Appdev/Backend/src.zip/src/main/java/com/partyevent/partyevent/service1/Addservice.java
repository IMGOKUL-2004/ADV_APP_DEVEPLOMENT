package com.partyevent.partyevent.service1;

import com.partyevent.partyevent.dto.Addevdto;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

import com.partyevent.partyevent.Entity.Addevent;
import com.partyevent.partyevent.Mapper.Addmap;
import com.partyevent.partyevent.Repository.Addrepo;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class Addservice {

    private final Addrepo serviceRepo;

    public Addservice(Addrepo serviceRepo) {
        this.serviceRepo = serviceRepo;
    }

    public List<Addevdto> getAllServices() {
        List<Addevent> services = serviceRepo.findAll();
        return services.stream()
                .map(Addmap::maptoServicedto)
                .collect(Collectors.toList());
    }
    
    @SuppressWarnings("null")
    public Addevdto createService(Addevdto servicedto) {
        Addevent serviceentity = Addmap.maptoServiceentity(servicedto);
        serviceentity = serviceRepo.save(serviceentity);
        return Addmap.maptoServicedto(serviceentity);
    }


    @Transactional
    public Addevdto updateServiceByEventId(Long eventid, Addevdto updatedServicedto) {
        Addevent existingService = serviceRepo.findById(eventid)
                .orElseThrow(() -> new EntityNotFoundException("Service not found for event ID: " + eventid));
        existingService.setEventtype(updatedServicedto.getEventtype());
        existingService.setDescription(updatedServicedto.getDescription());
        existingService.setEpackage(updatedServicedto.getEpackage());
        existingService.setCount(updatedServicedto.getCount());
        existingService.setCharge(updatedServicedto.getCharge());

        existingService = serviceRepo.save(existingService);
        return Addmap.maptoServicedto(existingService);
    }



    // public Addevdto getServiceByEventId(Long eventid) {
    //     Addevent addentity = serviceRepo.findById(eventid)
    //             .orElseThrow(() -> new EntityNotFoundException("Service not found for event ID: " + eventid));
    //     return Addmap.maptoServicedto(addentity);
    // }

    public Addevdto getServiceById(long eventid) {
        Addevent enqentity = serviceRepo.findById(eventid);
        return Addmap.maptoServicedto(enqentity);
    }

    @Transactional
    public void deleteServiceByEventId(Long eventid) {
        if (!serviceRepo.existsById(eventid)) {
            throw new EntityNotFoundException("Service not found for event ID: " + eventid);
        }
        serviceRepo.deleteById(eventid);
    }
}