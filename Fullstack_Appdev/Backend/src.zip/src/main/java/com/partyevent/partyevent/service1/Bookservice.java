package com.partyevent.partyevent.service1;

import com.partyevent.partyevent.dto.Bookdto;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

import com.partyevent.partyevent.Entity.Book;
import com.partyevent.partyevent.Mapper.Bookmap;
import com.partyevent.partyevent.Repository.Bookrepo;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class Bookservice {

    private final Bookrepo bookRepo;

    public Bookservice(Bookrepo bookRepo) {
        this.bookRepo = bookRepo;
    }

    public List<Bookdto> getAllServices() {
        List<Book> services = bookRepo.findAll();
        return services.stream()
                .map(Bookmap::maptoBookdto)
                .collect(Collectors.toList());
    }

    @SuppressWarnings("null")
    public Bookdto createService1(Bookdto servicedto1) {
        Book serviceentity = Bookmap.maptoBookentity(servicedto1);
        serviceentity = bookRepo.save(serviceentity);
        return Bookmap.maptoBookdto(serviceentity);
    }
    public List<Book> getfood(long s)
	{
		return bookRepo.getchefid(s);
	}
    
    public Bookdto updateStatusById(long bookingID, String status) {
        Book existingService = bookRepo.findById(bookingID);
        if (existingService != null) {
            // Update the status field
            existingService.setBookingstatus(status);
            
            // Save the updated entity
            existingService = bookRepo.save(existingService);
            
            // Map the updated entity to DTO and return
            return Bookmap.maptoBookdto(existingService);
        } else {
            // Handle not found scenario
            return null;
        }
    }

    @Transactional
    public void deleteServiceByBookingId(Long bookingID) {
        if (!bookRepo.existsById(bookingID)) {
            throw new EntityNotFoundException("Service not found for event ID: " + bookingID);
        }
        bookRepo.deleteById(bookingID);
    }
}