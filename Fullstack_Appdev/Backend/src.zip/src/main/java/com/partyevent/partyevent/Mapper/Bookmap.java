
package com.partyevent.partyevent.Mapper;

import com.partyevent.partyevent.dto.Bookdto;
import com.partyevent.partyevent.Entity.Book;

public class Bookmap{

    public static Bookdto maptoBookdto(Book ser) {
        // Implement the mapping logic
        return new Bookdto(
            ser.getBookingID(),
            ser.getSubmissionDate(),
            ser.getEventDate(),
            ser.getEventType(),
            ser.getHeadcount(),
            ser.getBookingstatus(),
            ser.getUserid(),
                ser.getUname()
        );
    }

    public static Book maptoBookentity(Bookdto serdto) {
        // Implement the mapping logic
        return new Book(
            serdto.getBookingID(),
            serdto.getSubmissionDate(),
            serdto.getEventDate(),
            serdto.getHeadcount(),
            serdto.getEventType(),
            serdto.getUserid(),
            serdto.getBookingstatus(),
            serdto.getUname()
        );
    }
}