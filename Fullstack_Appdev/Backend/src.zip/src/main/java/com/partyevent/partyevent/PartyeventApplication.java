package com.partyevent.partyevent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartyeventApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartyeventApplication.class, args);
	}

}
