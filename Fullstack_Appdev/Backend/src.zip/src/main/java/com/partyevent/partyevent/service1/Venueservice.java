package com.partyevent.partyevent.service1;


import com.partyevent.partyevent.dto.Venuedto;

import com.partyevent.partyevent.Entity.Venue;
import com.partyevent.partyevent.Mapper.Venuemap;
import com.partyevent.partyevent.Repository.Venuerepo;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class Venueservice {

    private final Venuerepo venueRepo;

    public Venueservice(Venuerepo venueRepo) {
        this.venueRepo = venueRepo;
    }

    public List<Venuedto> getAllServices() {
        List<Venue> services = venueRepo.findAll();
        return services.stream()
                .map(Venuemap::maptovenuedto)
                .collect(Collectors.toList());
    }

    @SuppressWarnings("null")
    public Venuedto createService2(Venuedto servicedto1) {
        Venue serviceentity = Venuemap.maptovenueentity(servicedto1);
        serviceentity = venueRepo.save(serviceentity);
        return Venuemap.maptovenuedto(serviceentity);
    }
    public List<Venue> getfood(long s)
	{
		return venueRepo.getchefid(s);
	}
}