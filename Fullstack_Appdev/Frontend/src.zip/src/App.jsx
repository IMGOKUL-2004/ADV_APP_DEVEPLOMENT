import { BrowserRouter, Routes, Route } from "react-router-dom";
import Signup from './Pages/Signup';
import Adminhome from './Pages/Adminhome';
import Login from "./Pages/Login";
import Addevents from "./Pages/Addevents";
// import Eventdetails from "./Components/Eventdetails";
// import Allevent from "./Pages/Allevent";
import Mybooking from "./Pages/Mybooking";
// import Unav from "./Components/Unav";
import Userhome from "./Pages/Userhome";
import Bookevent from "./Pages/Bookevent";
import Addbook from "./Pages/Addbook";
import Userbook from "./Pages/Userbook";
import Update from "./Pages/Update";
import All from "./Pages/All";
import First from "./Pages/First";
import Adminlogin from "./Pages/Adminlogin";
import Adminsign from "./Pages/Adminsign";
import Venue from "./Pages/Venue";
import Venueshow from "./Pages/Venueshow";
import Uservenue from "./Pages/Uservenue";


const App = () => {
  return (
    <BrowserRouter>
      <Routes>
      <Route path="/" element={<First/>}/>
        <Route path="Userlogin" element={<Login/>}/>
          <Route path="Signup" element={<Signup/>}/>
          <Route path="Admin" element={<Adminhome/>} />
          <Route path="Addev" element={<Addevents/>} />
          <Route path="Alogin" element={<Adminlogin/>} />
          <Route path="Asign" element={<Adminsign/>} />
          {/* <Route path="Allev" element={<Allevent/>} /> */}
          <Route path="Mybook" element={<Mybooking/>} />
          <Route path="Userhome" element={<Userhome/>} />
          <Route path="Bookev" element={<Bookevent/>} />
          <Route path="Addbook" element={<Addbook/>} />
          <Route path="/aa" element={<Update/>} />
          <Route path="Userbook" element={<Userbook/>} />
          <Route path="All" element={<All/>} />
          <Route path="Venue" element={<Venue/>} />
          <Route path="/VenueShow" element={<Venueshow/>} />
          <Route path="/Uservenue" element={<Uservenue/>} />



      </Routes>
    </BrowserRouter>
  )
}

export default App