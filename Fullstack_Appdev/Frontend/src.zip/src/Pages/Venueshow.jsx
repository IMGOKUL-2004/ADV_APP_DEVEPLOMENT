import './Venueshow.css'; 
import { useEffect,useState} from 'react';
import Navbar from '../Components/Navbar';
import axios from 'axios';
import Delete from '../Components/delete';

function Venueshow() {

  const[open2,setOpen1] = useState('');

  const [searchTerm, setSearchTerm] = useState('');

  

  const handleOpen1 = () => {
    setOpen1(true);
}
const id3=localStorage.getItem('id3');
const [data, setData] = useState([]);
useEffect(() => {
    console.log(id3);
    axios
      .get(`http://localhost:8080/venue/${id3}`)
      .then((response) => {
        setData(response.data);
        console.log(data.uname);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [id3]);

  const filteredEvents = data.filter(event =>
    event.venuename.toLowerCase().includes(searchTerm.toLowerCase())
  );


    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

  const handlesearchSubmit = (e) => {
    e.preventDefault();
    console.log('Search term submitted:', searchTerm);
  };

    return (
        <div className="bodyf111v">
        <Navbar/>
        <div className="bodyfv">
        <div className='be-h1v'>
        </div>
        <form className="search-formv" onSubmit={handlesearchSubmit}>
        <input
          className="search-inputv"
          type="text"
          placeholder="Type here to Search...."
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </form>

      {filteredEvents.length === 0 && (
      <div className="be-nonev">
        <img className="be-noeventsv" src="https://img.freepik.com/free-vector/illustrated-appointment-booking-with-calendar-concept_52683-38825.jpg?w=900&t=st=1706329469~exp=1706330069~hmac=d600cf38880c18cf106c110391f4466bdc9a93adbfcaed0132d4c89e9516c6d0"></img>
        <h3>Oops! No Upcoming Events for Now...</h3>
        <p>Watch this space for upcoming events!</p>
      </div>
        )}
      
        <br></br><br></br>
        

        <div className='be-gridv'>
        {filteredEvents.map(event => (
          <div key={event.venueid}>
            <div className="grid-itemv">
            <img className="img-fluidv w-100 mb-3 img-thumbnail shadow-sm rounded-0" src={event.venueimg} alt="" />
                {/* <img className="img-fluidv w-100 mb-3 img-thumbnail shadow-sm rounded-0" src="https://birthdaywisheszone.com/wp-content/uploads/2020/01/fc98a72dd575583ebc02c666ff75a58e.jpeg" alt="" /> */}
                <p className="font-italicv"><b>Venue Name: </b>{event.venuename}</p>
                <p className="font-italicv"><b>Venue Location:</b>{event.venuelocation}</p>
                <div className="buttv">
                <button className='button-2v'onClick={() => handleOpen1()}>DELETE</button>
                </div>
                </div>
       </div>
       ))}
       {open2 && (<Delete/>)} 
        </div>
        </div>
      </div>
      

        
  )
}

export default Venueshow;