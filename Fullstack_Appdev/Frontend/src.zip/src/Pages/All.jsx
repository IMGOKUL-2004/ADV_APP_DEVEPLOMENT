import './All.css'; 
import { useEffect,useState} from 'react';
import Update from './Update';
import Navbar from '../Components/Navbar';
import axios from 'axios';
import Delete from '../Components/delete';
import Venue from './Venue';
import { useNavigate } from 'react-router-dom';

function All() {

  const[open1,setOpen] = useState('');
  const[open2,setOpen1] = useState('');
  const[open3,setOpen3] = useState('');
  // const[open4,setOpen4] = useState('');



  const [searchTerm, setSearchTerm] = useState('');
  const [eventType, setEventType] = useState('');
  const [Id, setEventId] = useState('');

  const [id1, setId1] = useState('');
  const handleOpen = (id1) => {
      setOpen(true);
      setId1(id1);

  }

  const [id2, setId2] = useState('');
  const handleOpen3 = (id2) => {
      setOpen3(true);
      setId2(id2);

  }
  const navigate=useNavigate()
  const [id3, setId3] = useState('');
  const handleOpen4 = (id3) => {
      // setOpen4(true);
      setId3(id3);
      localStorage.setItem("id3",id3);
      navigate("/VenueShow")
  }

  const handleOpen1 = (eventType,Id) => {
    setOpen1(true);
    setEventType(eventType);
    setEventId(Id);
}
  const [data, setData] = useState([]);
  useEffect(() => {
        axios
          .get("http://localhost:8080/addevent")
          .then((response) => {
            setData(response.data);
          })
          .catch((error) => {
            console.log(error);
          });
      }, []);

  const filteredEvents = data.filter(event =>
    event.eventtype.toLowerCase().includes(searchTerm.toLowerCase())
  );


    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

  const handlesearchSubmit = (e) => {
    e.preventDefault();
    // Handle the search submission (e.g., send search query to the server)
    console.log('Search term submitted:', searchTerm);
  };

    return (
        <div className="bodyf111">
        <Navbar/>
        <div className="bodyf">
        <div className='be-h1'>
        </div>
        <form className="search-form" onSubmit={handlesearchSubmit}>
        <input
          className="search-input"
          type="text"
          placeholder="Type here to Search...."
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </form>

      {filteredEvents.length === 0 && (
      <div className="be-none">
        <img className="be-noevents" src="https://img.freepik.com/free-vector/illustrated-appointment-booking-with-calendar-concept_52683-38825.jpg?w=900&t=st=1706329469~exp=1706330069~hmac=d600cf38880c18cf106c110391f4466bdc9a93adbfcaed0132d4c89e9516c6d0"></img>
        <h3>Oops! No Upcoming Events for Now...</h3>
        <p>Watch this space for upcoming events!</p>
      </div>
        )}
      
        <br></br><br></br>
        

        <div className='be-grid'>
        {filteredEvents.map(event => (
          <div key={event.id}>
            <div className="grid-item">
                <img className="img-fluid w-100 mb-3 img-thumbnail shadow-sm rounded-0" src="https://birthdaywisheszone.com/wp-content/uploads/2020/01/fc98a72dd575583ebc02c666ff75a58e.jpeg" alt="" />
                <p className="font-italic"><b>Event Type: </b>{event.eventtype}</p>
                <p className="font-italic"><b>Event Description:</b>{event.description}</p>
                <p className="font-italic"><b>Event Package:</b>{event.epackage}</p>
                <p className="font-italic"><b>Participants Count:</b>{event.count}</p>
                <p className="font-italic"><b>Charges:</b>{event.charge}</p>
                <div className="butt">
                <button className='button-1' onClick={() => handleOpen(event.eventid)}>UPDATE</button>
                <button className='button-2'onClick={() => handleOpen1(event.eventtype,event.eventid)}>DELETE</button>
                </div>
                <div className="butt1">
                <button className='button-3' onClick={() => handleOpen3(event.eventid)}>ADD VENUE</button>
                <button className='button-4'onClick={() => handleOpen4(event.eventid)}>VIEW VENUE</button>

                </div>
                </div>
       </div>
       ))}
       {open2 && (<Delete eventType={eventType} Id={Id}/>)} 
       {open1 && (<Update id1={id1} />)} 
       {open3 && (<Venue id2={id2} />)} 


        </div>
        </div>
      </div>
      

        
  )
}

export default All;