// import Navbar from '../Components/Navbar';
import Navbar from '../Components/Navbar';
import './Mybooking.css';
import{ useState, useEffect } from 'react';
import axios from 'axios';
// import survey from './cheffinder-logo.png';
// import {Link} from "react-router-dom"


function Mybooking() {

  const [data, setData] = useState([]);
  const filteredEvents = data;
  useEffect(() => {
    axios
      .get("http://localhost:8080/bookevent")
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleStatusChange = async (eventId, status) => {
    console.log("Updating status for event ID:", eventId);
    console.log("New status:", status);
    try {
        await axios.put(`http://localhost:8080/bookevent/update/${eventId}`, status, {
            headers: {
                'Content-Type': 'text/plain'
            }
        });
        window.location.href="/Mybook";
        alert("Booking Status Updated Successfully!");
        console.log("Booking status updated successfully!");
    } catch (error) {
        console.error("Error updating booking status:", error);
        alert("Updating Booking Status Failed...Please Try Again!");
    }
}
  return (
    <div className="backq1">
        <Navbar/>
        <table className="table11">
        <thead>
          <tr>
            <th>Name</th>
            <th>Submission Date</th>
            <th>Event Date</th>
            <th>Event Type</th>
            <th>Head Count</th>
            <th>Booking Status</th>
          </tr>
        </thead>
        <tbody>
            {filteredEvents.map(event => (
            <tr key={event.bookingID}>
              <td>{event.uname}</td>
              <td>{event.submissionDate}</td>
              <td>{event.eventDate}</td>
              <td>{event.eventType}</td>
              <td>{event.headcount}</td>
              <td><select
                      value={event.bookingstatus}
                      onChange={(e) => {
                        handleStatusChange(event.bookingID, e.target.value);
                      }}
                      className={event.bookingstatus.toLowerCase() === 'pending' ? 'pe1' : event.bookingstatus.toLowerCase() === 'confirmed' ? 'con1' : 're1'}
                    >
                      <option className="drop" value="Pending">Pending</option>
                      <option className="drop" value="Confirmed">Confirmed</option>
                      <option className="drop" value="Rejected">Rejected</option>
                    </select></td>
            </tr>
            ))}
        </tbody>
      </table>
    </div>
  )
}

export default Mybooking;