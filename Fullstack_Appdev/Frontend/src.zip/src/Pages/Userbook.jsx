// import Navbar from '../Components/Navbar';
import Unav from '../Components/Unav';
import './Userbook.css';
import{ useState, useEffect } from 'react';
// import survey from './cheffinder-logo.png';
// import {Link} from "react-router-dom"
import axios from 'axios';
import Deletebook from '../Components/Deletebook';


function Userbook() {
  const [Id2, setEventId] = useState('');
  const [eventType, setEventType] = useState('');

  const[open7,setOpen1] = useState('');

  const handleOpen1 = (eventType,Id2) => {
    setOpen1(true);
    setEventType(eventType);
    setEventId(Id2);
}

  const [data, setData] = useState([]);
  let Id=localStorage.getItem('user');
  useEffect(() => {
    axios
      .get(`http://localhost:8080/bookevent/${Id}`)
      .then((response) => {
        setData(response.data);
        console.log(data.uname);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [Id]);

  const filteredEvents = data;

  return (
    <div className="backq11">
      <Unav/>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Submission Date</th>
            <th>Event Date</th>
            <th>Event Type</th>
            <th>Head Count</th>
            <th>Booking Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
            {filteredEvents.map(event => (
            <tr key={event.bookingID}>
              <td>{event.uname}</td>
              <td>{event.submissionDate}</td>
              <td>{event.eventDate}</td>
              <td>{event.eventType}</td>
              <td>{event.headcount}</td>
              <td><button className={event.bookingstatus.toLowerCase() === "pending" ? 'pe' : event.bookingstatus.toLowerCase() === 'confirmed' ? 'con1' : 're1'}>{event.bookingstatus}</button></td>
              <td><img onClick={() => handleOpen1(event.eventType,event.bookingID)} className="ve-img211" src="https://cdn-icons-png.flaticon.com/512/6861/6861362.png"></img></td>

            </tr>
            ))} {open7 && (<Deletebook eventType={eventType} Id2={Id2}/>)} 
        </tbody>
      </table>
    </div>
  )
}

export default Userbook;