import './Venue.css';
import { useState } from 'react';
// import Select from 'react-select';
import axios from 'axios';

function Venue({id2}) {
    const [isActive, setIsActive] = useState(false);

    const handleButtonClick = () => {
        setIsActive((prev) => !prev);
    };
    const [venuename, setUname] = useState("");
    const [venuelocation, setSub] = useState("");
    const [venueimg, setEventDate] = useState("");
    // const [eventType, seteventType] = useState("");
    // const [bookingstatus, setStatus] = useState("");

    const handleUname = (event) => {
        setUname(event.target.value);
    }
    const handleSub = (event) => {
        setSub(event.target.value);
    }

    const handleDate = (event) => {
        setEventDate(event.target.value);
    }


    // const handleType = (event) => {
    //     seteventType(event.target.value);
    // }
    // const handleStatus = (event) => {
    //     setStatus(event.target.value);
    // }
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(
                "http://localhost:8080/venue/posts",
                { venuename, venuelocation, venueimg, eveid:id2}
            );
            console.log("Added successful");
            console.log(response.data);
            setSub("");
            setEventDate("");
            setUname("");
            // navigate("/Userlogin");
        } catch (error) {
            console.error("Added is failed");
            console.error(error);
        } 
    }
    return (
        <div>
            <div className="modal-containerv">
                <div className="modal-contentv">
                    <div className="evnt-create-boxv">
                        <div className=''>
                            <a href="/All"><img className="eb-imgv" src="https://openclipart.org/image/2400px/svg_to_png/183568/close-button.png"></img></a>
                            <h1 className='eb-h1v'>Add Venue:</h1><br></br>
                            <form className='event-detailsv' onSubmit={handleSubmit}>
                                <div className="evetv">
                                <div className='event-itemsv'>
                                    <label className='eb-labelv'>Venue Name</label>
                                    <input className="eb-inputv" type="text" value={venuename} onChange={handleUname} />
                                    <label className='eb-labelv'>Venue Location</label>
                                    <input className="eb-inputv" type="text" value={venuelocation} onChange={handleSub}  required/>
                                    <label className='eb-labelv'>Venue Img</label>
                                    <input className="eb-inputv" type="text" value={venueimg} onChange={handleDate}  required/>
                                </div>
                                </div>
                                <div  className='event-itemsv'>
                                    <div className={`eb-box1v ${isActive ? 'active' : ''}`}>
                                        <input className='eb-box2v' type="checkbox"required/>
                                        <p className="eb-box3v">Confirm the Entered Details!!!</p>
                                    </div>
                                    <div className={`wrapperv ${isActive ? 'active' : ''}`}>
                                        <button type="submit" className={`custom-buttonv ${isActive ? 'is_active' : ''}`} onClick={handleButtonClick} >
                                            <span>ADD</span>
                                            <div className="successv">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29.756 29.756" >
                                                    <path d="M29.049,5.009L28.19,4.151c-0.943-0.945-2.488-0.945-3.434,0L10.172,18.737l-5.175-5.173   c-0.943-0.944-2.489-0.944-3.432,0.001l-0.858,0.857c-0.943,0.944-0.943,2.489,0,3.433l7.744,7.752   c0.944,0.943,2.489,0.943,3.433,0L29.049,8.442C29.991,7.498,29.991,5.953,29.049,5.009z" />
                                                </svg>
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Venue;
