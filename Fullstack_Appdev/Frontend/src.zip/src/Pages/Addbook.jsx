import './Addbook.css';
import { useState } from 'react';
// import Select from 'react-select';
import axios from 'axios';

function Addbook() {
    const [isActive, setIsActive] = useState(false);

    const handleButtonClick = () => {
        setIsActive((prev) => !prev);
    };
    const [uname, setUname] = useState("");
    const [submissionDate, setSub] = useState("");
    const [eventDate, setEventDate] = useState("");
    const [headcount, setHeadcount] = useState("");
    const [eventType, seteventType] = useState("");
    // const [bookingstatus, setStatus] = useState("");

    const handleUname = (event) => {
        setUname(event.target.value);
    }
    const handleSub = (event) => {
        setSub(event.target.value);
    }

    const handleDate = (event) => {
        setEventDate(event.target.value);
    }

    const handleHead = (event) => {
        setHeadcount(event.target.value);
    }

    const handleType = (event) => {
        seteventType(event.target.value);
    }
    // const handleStatus = (event) => {
    //     setStatus(event.target.value);
    // }
    const handleSubmit = async (e) => {
        e.preventDefault();
        let id=localStorage.getItem('user');
        console.log(id);
        try {
            const response = await axios.post(
                "http://localhost:8080/bookevent/posts",
                { uname, submissionDate, eventDate, headcount, eventType ,userid:id,bookingstatus:"pending"}
            );
            console.log("Added successful");
            console.log(response.data);
            setSub("");
            setEventDate("");
            setHeadcount("");
            seteventType("");
            setUname("");
            // navigate("/Userlogin");
        } catch (error) {
            console.error("Added is failed");
            console.error(error);
        } 
    }
    return (
        <div>
            <div className="modal-container">
                <div className="modal-content">
                    <div className="evnt-create-box">
                        <div className=''>
                            <a href="/Bookev"><img className="eb-img" src="https://openclipart.org/image/2400px/svg_to_png/183568/close-button.png"></img></a>
                            <h1 className='eb-h1'>Book your Event:</h1><br></br>
                            <form className='event-details' onSubmit={handleSubmit}>
                                <div className="evet">
                                <div className='event-items'>
                                    <label className='eb-label'>Name</label>
                                    <input className="eb-input" type="text" value={uname} onChange={handleUname}  placeholder="User Name"/>
                                    <label className='eb-label'>Submission Date</label>
                                    <input className="eb-input" type="date" value={submissionDate} onChange={handleSub}  placeholder="Enter Applicant Name"  required/>
                                    <label className='eb-label'>Event Date</label>
                                    <input className="eb-input" type="date" value={eventDate} onChange={handleDate}  placeholder="Enter the Age"  required/>
                                </div>
                                <div  className='event-items'>
                                <label className='eb-label'>HeadCount</label>
                                    <input className="eb-input" type="text" value={headcount} onChange={handleHead}  placeholder="Enter Description" required />
                                    <label className='eb-label'>Event Type</label>
                                    <input className="eb-input" type="text" value={eventType}  onChange={handleType} placeholder="Enter Event Type"  required/>
                                    {/* <label className='eb-label'>Bookstatus</label>
                                    <input className="eb-input" type="text" value={bookingstatus} onChange={handleStatus}  placeholder="Enter Event Type"  required/> */}
                                </div>
                                </div>
                                <div  className='event-items'>
                                    <div className={`eb-box1 ${isActive ? 'active' : ''}`}>
                                        <input className='eb-box2' type="checkbox"required/>
                                        <p className="eb-box3">Confirm the Entered Details!!!</p>
                                    </div>
                                    <div className={`wrapper ${isActive ? 'active' : ''}`}>
                                        <button type="submit" className={`custom-button ${isActive ? 'is_active' : ''}`} onClick={handleButtonClick} >
                                            <span>Book Event</span>
                                            <div className="success">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29.756 29.756" >
                                                    <path d="M29.049,5.009L28.19,4.151c-0.943-0.945-2.488-0.945-3.434,0L10.172,18.737l-5.175-5.173   c-0.943-0.944-2.489-0.944-3.432,0.001l-0.858,0.857c-0.943,0.944-0.943,2.489,0,3.433l7.744,7.752   c0.944,0.943,2.489,0.943,3.433,0L29.049,8.442C29.991,7.498,29.991,5.953,29.049,5.009z" />
                                                </svg>
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Addbook;
