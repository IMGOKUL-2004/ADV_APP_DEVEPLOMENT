import { useState,useEffect } from "react";
import './Signup.css';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
const Signup = () => {
    const [name, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [conpassword, setConPassword] = useState("");
    // const [mobile, setMobile] = useState("");
    const [password, setPassword] = useState("");
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setIsSubmit] = useState(false);
    const navigate=useNavigate();

    const handleName = (event) => {
        setUsername(event.target.value);
    }

    const handleEmail = (event) => {
        setEmail(event.target.value);
    }

    const handlePwd = (event) => {
        setPassword(event.target.value);
    }

    const handleConpass = (event) => {
        setConPassword(event.target.value);
    }

    // const handleNumber = (event) => {
    //     setMobile(event.target.value);
    // }

    const handleSubmit = async (event) => {
        event.preventDefault();
        const errors = validate({ email, password, conpassword });
        if (Object.keys(errors).length === 0) {
            setIsSubmit(true);
        } else {
            setFormErrors(errors);
            setIsSubmit(false);
        }
    }

    useEffect(() => {
        if (isSubmit) {
            submitForm();
        }
    }, [isSubmit]);

    const submitForm = async () => {
        try {
            const response = await axios.post(
                "http://localhost:8080/api/v1/auth/register",
                { name, email, password }
            );
            console.log("Sign up successful");
            console.log(response.data);
            // Clear form fields
            setUsername("");
            setEmail("");
            setPassword("");
            setConPassword("");
            navigate("/Userlogin");
        } catch (error) {
            console.error("Registration failed");
            console.error(error);
        } finally {
            setIsSubmit(false);
        }
    }

    const validate = (values) => {
        const errors = {};
        const preg = new RegExp("[A-Z][A-Za-z0-9$_]+");

        if (!values.email) {
            errors.email = "Email is Required";
        }

        if (!preg.test(values.password)) {
            errors.password = "Invalid password";
        }

        if (values.password !== values.conpassword) {
            errors.conpassword = "Passwords do not match";
        }


        return errors;
    }

    return (
        <div className="back">
            <div className="log">
                <form onSubmit={handleSubmit}>
                    <br />
                    <center><h1 className="h1n1">SIGN UP</h1></center>
                    <h1>                  </h1>
                    <div className="input">
                        <label name="uname1">Username</label>
                        <input type="text" value={name} onChange={handleName} required id="uname" />
                    </div>
                    <div className="input">
                        <label name="uname1">Email</label>
                        <input type="email" value={email} onChange={handleEmail} required id="uname3" />
                    </div>
                    <div className="input">
                        <label name="pass">Password</label>
                        <input type="password" required id="pass" value={password} onChange={handlePwd} />
                    </div>
                    <p style={{ color: "white", fontSize: "17px" }}>{formErrors.password}</p>
                    <div className="input">
                        <label name="pass1">Confirm Password</label>
                        <input type="password" required id="pass1" value={conpassword} onChange={handleConpass} />
                    </div>
                    <p style={{ color: "white", fontSize: "17px" }}>{formErrors.conpassword}</p>
                    
                    <center>
                        <button className="but" type="submit">
                            Sign Up
                        </button>
                    </center>
                </form>
            </div>
        </div>
    );
}

export default Signup;

// import { useState,} from "react";
// import './Signup.css';
// // import { Link } from "react-router-dom";
// import {useNavigate} from "react-router-dom"
// import axios from 'axios';

// const Signup=()=>{
//   const [name, setName] = useState('');
//   const [email, setEmail] = useState('');
//   const [mobile, setMobile] = useState('');
//   const [password, setPassword] = useState('');
//   const [confirmpassword, setConfirmPassword] = useState('');
//   // const [registrationError,setRegistrationError] = useState('');
//   const navigate=useNavigate();

//   const checkPassword = () =>{
//    const mobileRegex=/^\d{10}$/;
//    const passwordRegex =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,}$/;
//    if(!mobileRegex.test(mobile)){
//      window.alert(
//        "Mobile number must contain 10 Numbers."
//      );
//      initialize3()
//      return;
//    }
//    else if (!passwordRegex.test(password)) {
//      window.alert(
//        "Password should contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character."
//      );
//      initialize1()
//      return;
//    }
//    else if (password !== confirmpassword) {
//      window.alert("Passwords do not match.");
//      initialize2()
//      return;
//    }
//    else{
//      window.alert("Registration Successful !!!");
//    }
//  }
//  const initialize1 = () =>{
//    setPassword('')
//    setConfirmPassword('')
//  }
//  const initialize2 = () =>{
//    setConfirmPassword('')
//  }
//  const initialize3 = () =>{
//    setMobile('')
//  }

//  const handleNameChange = (event) => {
//      setName(event.target.value);
     
//    };
//  const handleEmailChange = (event) => {
//    setEmail(event.target.value);
//  };

//  const handlePasswordChange = (event) => {
//    setPassword(event.target.value);
//  };
 
//  const handleConfirmPasswordChange = (event) => {
//    setConfirmPassword(event.target.value);
//  };

//  const handleMobileChange = (event) => {
//    setMobile(event.target.value);
//  };

//  const handleSubmit= async (e)=>{
//    e.preventDefault();
//    console.log(name);
//    try {
//      const response = await axios.post(
//        "http://localhost:8080/api/v1/auth/register",
//        {
//          name,
//          email,
//          mobile,
//          password,
//        }
//      );

//      console.log("Sign in successful");
//      console.log(response.data); 
//      navigate('/UserLogin');

//      // setName("");
//      // setEmail("");
//      // setMobile("");
//      // setPassword("");
//      // setRegistrationError("");
//    } catch (error) {
//      console.error("Registration failed");
//      console.error(error); 

//    }
// }
//     return(
//       <div className="back">
//       <div className="log">
//         <form onSubmit={handleSubmit}>
//        <br/>
//         <center><h1 className="h1n1">SIGN UP</h1>
//        </center>
//        <h1>                  </h1>
//        <div className="input">
//             <label name="uname1">Username</label>
//             <input type="text" value={name} onChange={handleNameChange} required id="uname"/>
//           </div>
//           <div className="input">
//             <label name="uname1">Email</label>
//             <input type="email" value={email} onChange={handleEmailChange} required id="uname3" />
//           </div>
//             <div className="input">
//             <label name="pass">Password</label>
//             <input  type="password" required id="pass" value={password} onChange={handlePasswordChange}/>
//           </div>
//           {/* <p  style={{color:"white",fontSize:"17px"}}>{formErrors.password}</p>       */}
//           <div className="input">
//             <label name="pass1">Confirm Password</label>
//             <input  type="password" required id="pass1" value={confirmpassword} onChange={handleConfirmPasswordChange}/>
//           </div>
//           {/* <p  style={{color:"white",fontSize:"17px"}}>{formErrors.conpassword}</p>   */}
//           <div className="input">
//             <label name="num">Phone Number</label>
//             <input  type="text" required id="num" value={mobile} onChange={handleMobileChange}/>
//           </div>
//           {/* <p  style={{color:"white",fontSize:"17px"}}>{formErrors.number}</p>      */}
//           <center>
//             <button className="but" type="submit"  onClick={checkPassword}>
//               Sign Up
//             </button>
//           </center>
//         </form>
//       </div>
//       </div>
        
//     )
// }

// export default Signup;


// import { useState } from "react";
// import './Signup.css';
// import { useNavigate } from "react-router-dom";
// import axios from 'axios';

// const Signup = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     mobile: '',
//     password: '',
//     confirmPassword: ''
//   });

//   const navigate = useNavigate();

//   const handleChange = (event) => {
//     const { name, value } = event.target;
//     setFormData({ ...formData, [name]: value });
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     try {
//       const response = await axios.post(
//         "http://localhost:8080/api/v1/auth/register",
//         formData
//       );

//       console.log("Sign in successful");
//       console.log(response.data); 
//       navigate('/UserLogin');
//     } catch (error) {
//       console.error("Registration failed");
//       console.error(error); 
//     }
//   };

//   const checkPassword = () => {
    
//   };

//   return (
//     <div className="back">
//       <div className="log">
//         <form onSubmit={handleSubmit}>
//           <br/>
//           <center><h1 className="h1n1">SIGN UP</h1></center>
//           <h1>                  </h1>
//           <div className="input">
//             <label htmlFor="uname">Username</label>
//             <input type="text" name="name" value={formData.name} onChange={handleChange} required id="uname"/>
//           </div>
//           <div className="input">
//             <label htmlFor="email">Email</label>
//             <input type="email" name="email" value={formData.email} onChange={handleChange} required id="email" />
//           </div>
//           <div className="input">
//             <label htmlFor="pass">Password</label>
//             <input  type="password" name="password" required id="pass" value={formData.password} onChange={handleChange}/>
//           </div>
//           <div className="input">
//             <label htmlFor="pass1">Confirm Password</label>
//             <input  type="password" name="confirmPassword" required id="pass1" value={formData.confirmPassword} onChange={handleChange}/>
//           </div>
//           <div className="input">
//             <label htmlFor="num">Phone Number</label>
//             <input  type="text" name="mobile" required id="num" value={formData.mobile} onChange={handleChange}/>
//           </div>
//           <center>
//             <button className="but" type="submit" onClick={checkPassword}>
//               Sign Up
//             </button>
//           </center>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default Signup;
