import './Delete.css';
// import { useState } from 'react';
// import logo10 from '../Assets/Logo2.jpg'
// import {Link} from 'react-router-dom'
import axios from 'axios';
// import { useNavigate } from "react-router-dom";



function Deletebook({eventType, Id2}) {

    // const navigate=useNavigate();
    console.log(Id2)
    const handleButtonClick = async () => {
        try {
            await axios.delete(`http://localhost:8080/bookevent/${Id2}`);
            window.location.href = "/Userbook";
            alert("Event Deleted Successfully!");
        } catch (error) {
            alert("Failed to Delete Event!");
            console.error(error);
        }
    };
    return (
        <div>
            <div className="del-modal-container">
                <div className="del-modal-content">
                <div className="del-evnt-create-box">
                    <div className=''>
                        <a href="/Userbook"><img className="del-img" src="https://cdn-icons-png.flaticon.com/512/8367/8367508.png"></img></a>
                            <div className="del-msg">
                                <h3 className="del-msg1">Do you want to delete&nbsp;' {eventType} ' Book by You?&nbsp;</h3>
                            </div>
                            <br></br>
                            <a href="/Userbook"><button className="del-can">Cancel</button></a><button onClick={handleButtonClick} className="del-del">Delete</button>

                            </div>
                            
                    </div>
                </div>
                </div>
            </div>
    )
}
export default Deletebook;