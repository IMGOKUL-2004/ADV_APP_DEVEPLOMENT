// // import React from 'react'
// import './Eve.css'

// const Eve = () => {
//   return (
//     <div>
//             {/* <div className="gallery-wrapper"> */}
//                 {/* <div className="grid-sizer"></div> */}
//                 <div className="grid-item">
//                 <img className="img-fluid w-100 mb-3 img-thumbnail shadow-sm rounded-0" src="https://birthdaywisheszone.com/wp-content/uploads/2020/01/fc98a72dd575583ebc02c666ff75a58e.jpeg" alt="" />
//                 <p className="font-italic"><b>Event Type:</b> </p>
//                 <p className="font-italic"><b>Event Description:</b>  jdxjjfxhjhf gfjf</p>
//                 <p className="font-italic"><b>Event Package:</b> </p>
//                 <p className="font-italic"><b>Participants Count:</b> </p>
//                 <p className="font-italic"><b>Charges:</b> </p>
//                 <div className="butt">
//                 <button className='button-1'>UPDATE</button>
//                 <button className='button-2'>DELETE</button>
//                 </div>
//                 </div>
//             </div>

//     // </div>
//   )
// }

// export default Eve